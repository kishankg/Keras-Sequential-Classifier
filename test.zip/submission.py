import cv2
import numpy as np
def transform(array_of_images):
    X = []
    for image in array_of_images:
        processedImg = cv2.resize(image,(128,128))
        X.append(processedImg)
    processed_images = np.array(X,dtype=np.float32)
    return processed_images
